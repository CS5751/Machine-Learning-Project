The algorithm is in the form of a standard python jupyter notebook file (.ipynb).
No special libraries beyond standard python should be needed to run the notebook.
The data is a bare bones version of our full set with the last column being the classifier
Dem = 1 and Rep = 0
You may need to manually set which directory that python is looking for the data